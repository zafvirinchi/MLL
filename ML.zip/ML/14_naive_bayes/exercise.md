### Machine Learning Tutorial - Naive Bayes: Exercise

Use wine dataset from sklearn.datasets to classify wines into 3 categories. Load the dataset and split it into test and train. After that train the model using Gaussian and Multinominal classifier and post which model performs better. Use the trained model to perform some predictions on test data.

[Solution](https://github.com/codebasics/py/blob/master/ML/14_naive_bayes/Exercise/14_naive_bayes_exercise.ipynb)